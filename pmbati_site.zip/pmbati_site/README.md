# P&M Bâti — Site statique prêt à publier

**Comment mettre en ligne :**
1. Ouvrez `index.html` pour prévisualiser localement.
2. Pour publier facilement : envoyez tout le dossier sur Netlify, GitHub Pages, OVH, Ionos ou Hostinger (hébergement statique).
3. Le formulaire utilise `mailto:` (ouvre l’email du client). Pour une vraie réception côté serveur, branchez un service (Formspree, Netlify Forms) ou un script PHP.

**Personnalisation rapide :**
- Remplacez les images `assets/img/*` par vos photos de chantiers (gardez les mêmes noms de fichiers).
- Modifiez couleurs/typos via `assets/css/style.css`.
